Proiectul se compileaza folosind xelatex sau lualatex (NU pdflatex).

Fisierul principal este thesis.tex. Acesta referentieaza toate celelalte fisiere auxiliare.

Structura de sub-foldere (se recomanda a se folosi pentru a lucra organizat) este:

./chapters - aici se stocheaza fisierele tex corespunzatoare unui capitol al lucrarii
./code - fisiere sursa ce sunt referentiate in lucrare
./pics - imagini ce sunt referentiate in lucrare
./cls -diverse fisiere auxiliare necesare pentru compilare; singurul fisier in care este necesar sa se umble (daca folositi bibtex pentru generarea de referinte) este bib.bib